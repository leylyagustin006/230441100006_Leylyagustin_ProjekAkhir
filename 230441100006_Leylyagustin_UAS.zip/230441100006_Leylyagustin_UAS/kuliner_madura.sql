-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2024 at 01:28 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kuliner_madura`
--

-- --------------------------------------------------------

--
-- Table structure for table `makanan_khas`
--

CREATE TABLE `makanan_khas` (
  `id` int(11) NOT NULL,
  `kabupaten` varchar(50) NOT NULL,
  `nama_makanan` varchar(100) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `makanan_khas`
--

INSERT INTO `makanan_khas` (`id`, `kabupaten`, `nama_makanan`, `alamat`) VALUES
(1, 'Bangkalan', 'Bebek Sinjay', 'Jl. Raya Ketengan No. 45, Bangkalan\r\n'),
(2, 'Bangkalan', 'Topak Ladeh', 'jl.rambutan'),
(3, 'Bangkalan', 'bebek', 'Jl.rmbtn'),
(4, 'Sampang', 'Kaldu Kokot', 'Jl. Trunojoyo No. 23, Sampang\r\n'),
(5, 'Sampang', 'Tajhin Sobih', 'Jl. Pemuda No. 5, Sampang\r\n'),
(6, 'Sampang', 'Nasi Jagung', 'Jl. Pasar Sampang No. 15, Sampang\r\n'),
(7, 'Pamekasan', 'Rujak Tajhin', 'Jl. Pendidikan No. 27, Pamekasan\r\n'),
(8, 'Pamekasan', 'Nasi Serpang', 'Jl. Raya Serpang No. 18, Pamekasan\r\n'),
(9, 'Pamekasan', 'Soto Mata Sapi', 'Jl. Dr. Cipto No. 32, Pamekasan\r\n'),
(10, 'Sumenep', 'Sate Lalat', 'Jl. Diponegoro No. 50, Sumenep\r\n'),
(11, 'Sumenep', 'Kalsot (Kacang Lorjuk Asin)', 'Jl. Pahlawan No. 8, Sumenep\r\n'),
(12, 'Sumenep', 'Ayam Bakar', 'Jl.Mangga');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `makanan_khas`
--
ALTER TABLE `makanan_khas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `makanan_khas`
--
ALTER TABLE `makanan_khas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
